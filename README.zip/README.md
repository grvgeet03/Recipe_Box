# RecipeBox

An android app that contains recipes.
You need to log in to use this app, if you dont have an account you can create a new one.

All the work done in this project is my work and everything was made ground up from scratch.

I learnt all these things using YouTube. I didn’t had any prior knowledge of Android Studio.

It was a fun project and I learned a lot.

## Getting Started
- Clone this repo and unzip the folder wherever you want.
- Launch Android Studio choose open project.
- Locate where you unziped this clone.
- Select **RecipeBox-master** folder, let the gradle sync.
- You are ready to go!

## Screenshots of the App

 <br/>
 <p>
 <img src="Screenshots/1.jpeg" width="20%">
 <img src="Screenshots/2.jpeg" width="20%">
 <img src="Screenshots/3.jpeg" width="20%"> 
 <img src="Screenshots/4.jpeg" width="20%">
 <img src="Screenshots/5.jpeg" width="20%">
 <img src="Screenshots/6.jpeg" width="20%">
 <img src="Screenshots/7.jpeg" width="20%">
 <img src="Screenshots/9.jpeg" width="20%">
 </p>

# Things I learned

- Developed a user interface within the xml file using RelativeLayout, ListView, SearchView, RecyclerView, ScrollView, & Button.
- Implemented functinality to the UI: onCreate, onAddItem, setupListViewListener, readItems, WriteItems.
- Used Firebase to authenticate user, created a database to store user's info & get that data form online database.
